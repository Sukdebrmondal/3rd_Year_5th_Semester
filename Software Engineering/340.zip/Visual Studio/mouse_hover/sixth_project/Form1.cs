namespace sixth_project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // Helper: keep pictureBox1 fully inside the form client area
        private void ClampPictureBoxPosition()
        {
            if (pictureBox1 == null) return;

            int minX = 0;
            int minY = 0;
            int maxX = this.ClientSize.Width - pictureBox1.Width;
            int maxY = this.ClientSize.Height - pictureBox1.Height;

            int x = pictureBox1.Location.X;
            int y = pictureBox1.Location.Y;

            if (x < minX) x = minX;
            if (y < minY) y = minY;
            if (x > maxX) x = maxX;
            if (y > maxY) y = maxY;

            pictureBox1.Location = new Point(x, y);
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'w')
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X, pictureBox1.Location.Y - 5);
            }
            if (e.KeyChar == 's')
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X, pictureBox1.Location.Y + 5);
            }
            if (e.KeyChar == 'a')
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X - 5, pictureBox1.Location.Y);
            }
            if (e.KeyChar == 'd')
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X + 5, pictureBox1.Location.Y);
            }

            ClampPictureBoxPosition();
        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            Random random = new Random();
            pictureBox1.Location = new Point(pictureBox1.Location.X + random.Next(20, 50), pictureBox1.Location.Y - random.Next(3, 30));
            pictureBox1.Location = new Point(pictureBox1.Location.X - random.Next(20, 50), pictureBox1.Location.Y + random.Next(3, 30));
            pictureBox1.Location = new Point(pictureBox1.Location.X + random.Next(20, 50), pictureBox1.Location.Y + random.Next(3, 30));
            pictureBox1.Location = new Point(pictureBox1.Location.X - random.Next(20, 50), pictureBox1.Location.Y - random.Next(3, 30));

            ClampPictureBoxPosition();
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            Random random = new Random();
            if (pictureBox1.Location.X <= 0 ||  pictureBox1.Location.Y <= 0 || pictureBox1.Location.X >= 640 || pictureBox1.Location.Y >= 299)
            {
                pictureBox1.Location = new Point(random.Next(12, 640), random.Next(12, 299));
            }
            pictureBox1.Location = new Point(random.Next(12, 640), random.Next(12, 299));

            ClampPictureBoxPosition();
        }
    }
}

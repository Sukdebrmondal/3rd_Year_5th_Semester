using System.Xml;

namespace Application_Form
{
    public partial class Form1 : Form
    {
        public static string course = "";
        public static string name = "";
        public static string gender = "";
        public static string guardianname = "";
        public static string village = "";
        public static string postoffice = "";
        public static string policestation = "";
        public static string district = "";
        public static string pin = "";
        public static string country = "";
        public static string state = "";
        public static string email = "";
        public static string phone = "";
        public static string category = "";
        public static string dateofbirth = "";
        public static string boardname = "";
        public static string institution = "";
        public static string rollno = "";
        public static string passingyear = "";
        public static string subject1 = "";
        public static string subject2 = "";
        public static string subject3 = "";
        public static string subject4 = "";
        public static string subject5 = "";
        public static string mark1 = "";
        public static string mark2 = "";
        public static string mark3 = "";
        public static string mark4 = "";
        public static string mark5 = "";
        public static string submit = "";

        // List of all possible subjects
        private readonly string[] allSubjects = new string[]
        {
            "First Language", "Second Language", "Environmental Education", "Physics", "Chemistry", "Mathematics", "Biology ", " Statistics ", "Computer Science", "Psychology", "Physical Education", "History", "Political Science", "Geography", "Philosophy", "Education", "Sociology", "Economics", "Sanskrit"
        };

        // Helper to check if all required fields are filled
        private bool AllFieldsFilled()
        {
            // Check all required textboxes and comboboxes
            if (string.IsNullOrWhiteSpace(comboBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) ||
                (!radioButton1.Checked && !radioButton2.Checked) ||
                string.IsNullOrWhiteSpace(textBox5.Text) ||
                string.IsNullOrWhiteSpace(textBox6.Text) ||
                string.IsNullOrWhiteSpace(textBox7.Text) ||
                string.IsNullOrWhiteSpace(textBox8.Text) ||
                string.IsNullOrWhiteSpace(textBox9.Text) ||
                string.IsNullOrWhiteSpace(textBox10.Text) ||
                string.IsNullOrWhiteSpace(textBox11.Text) ||
                string.IsNullOrWhiteSpace(comboBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox18.Text) ||
                string.IsNullOrWhiteSpace(textBox19.Text) ||
                string.IsNullOrWhiteSpace(dateTimePicker1.Text) ||
                string.IsNullOrWhiteSpace(comboBox5.Text) ||
                string.IsNullOrWhiteSpace(textBox22.Text) ||
                string.IsNullOrWhiteSpace(textBox21.Text) ||
                string.IsNullOrWhiteSpace(comboBox4.Text) ||
                string.IsNullOrWhiteSpace(comboBox6.Text) ||
                string.IsNullOrWhiteSpace(comboBox7.Text) ||
                string.IsNullOrWhiteSpace(comboBox8.Text) ||
                string.IsNullOrWhiteSpace(comboBox9.Text) ||
                string.IsNullOrWhiteSpace(comboBox10.Text) ||
                string.IsNullOrWhiteSpace(textBox23.Text) ||
                string.IsNullOrWhiteSpace(textBox24.Text) ||
                string.IsNullOrWhiteSpace(textBox25.Text) ||
                string.IsNullOrWhiteSpace(textBox26.Text) ||
                string.IsNullOrWhiteSpace(textBox27.Text))
                return false;
            // If another number is visible, it must be filled
            if (textBox20.Visible && string.IsNullOrWhiteSpace(textBox20.Text))
                return false;
            return true;
        }

        // Helper to enable/disable submit button
        private void UpdateSubmitButtonState()
        {
            button1.Enabled = AllFieldsFilled();
        }

        // Call UpdateSubmitButtonState on all relevant input changes
        private void AttachFieldChangeHandlers()
        {
            comboBox1.SelectedIndexChanged += (s, e) => UpdateSubmitButtonState();
            textBox3.TextChanged += (s, e) => UpdateSubmitButtonState();
            radioButton1.CheckedChanged += (s, e) => UpdateSubmitButtonState();
            radioButton2.CheckedChanged += (s, e) => UpdateSubmitButtonState();
            textBox5.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox6.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox7.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox8.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox9.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox10.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox11.TextChanged += (s, e) => UpdateSubmitButtonState();
            comboBox2.SelectedIndexChanged += (s, e) => UpdateSubmitButtonState();
            textBox18.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox19.TextChanged += (s, e) => UpdateSubmitButtonState();
            dateTimePicker1.ValueChanged += (s, e) => UpdateSubmitButtonState();
            comboBox5.SelectedIndexChanged += (s, e) => UpdateSubmitButtonState();
            textBox22.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox21.TextChanged += (s, e) => UpdateSubmitButtonState();
            comboBox4.SelectedIndexChanged += (s, e) => UpdateSubmitButtonState();
            comboBox6.SelectedIndexChanged += (s, e) => UpdateSubmitButtonState();
            comboBox7.SelectedIndexChanged += (s, e) => UpdateSubmitButtonState();
            comboBox8.SelectedIndexChanged += (s, e) => UpdateSubmitButtonState();
            comboBox9.SelectedIndexChanged += (s, e) => UpdateSubmitButtonState();
            comboBox10.SelectedIndexChanged += (s, e) => UpdateSubmitButtonState();
            textBox23.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox24.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox25.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox26.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox27.TextChanged += (s, e) => UpdateSubmitButtonState();
            textBox20.TextChanged += (s, e) => UpdateSubmitButtonState();
            checkBox2.CheckedChanged += (s, e) => UpdateSubmitButtonState();
        }

        public Form1()
        {
            InitializeComponent();
            // Add KeyPress event handler for pin code validation
            textBox10.KeyPress += textBox10_KeyPress;
            // Add KeyPress event handler for permanent pin code validation
            textBox16.KeyPress += textBox16_KeyPress;
            // Add Validating event handler for email validation
            textBox18.Validating += textBox18_Validating;
            // Add KeyPress event handler for phone number validation
            textBox19.KeyPress += textBox19_KeyPress;
            // Add KeyPress event handler for another number validation
            textBox20.KeyPress += textBox20_KeyPress;
            // Add KeyPress and Validating event handlers for mark textboxes
            textBox23.KeyPress += markTextBox_KeyPress;
            textBox24.KeyPress += markTextBox_KeyPress;
            textBox25.KeyPress += markTextBox_KeyPress;
            textBox26.KeyPress += markTextBox_KeyPress;
            textBox27.KeyPress += markTextBox_KeyPress;
            textBox23.Validating += markTextBox_Validating;
            textBox24.Validating += markTextBox_Validating;
            textBox25.Validating += markTextBox_Validating;
            textBox26.Validating += markTextBox_Validating;
            textBox27.Validating += markTextBox_Validating;
            // Attach unified handler to all subject ComboBoxes
            comboBox6.SelectedIndexChanged += SubjectComboBox_SelectedIndexChanged;
            comboBox7.SelectedIndexChanged += SubjectComboBox_SelectedIndexChanged;
            comboBox8.SelectedIndexChanged += SubjectComboBox_SelectedIndexChanged;
            comboBox9.SelectedIndexChanged += SubjectComboBox_SelectedIndexChanged;
            comboBox10.SelectedIndexChanged += SubjectComboBox_SelectedIndexChanged;
            // Initialize subject ComboBoxes
            UpdateSubjectComboBoxes();
            AttachFieldChangeHandlers();
            UpdateSubmitButtonState();
            textBox21.Validating += textBox21_Validating;
            textBox21.KeyPress += textBox21_KeyPress;
        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            course = comboBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] labels = new[]
            {
                "Course:",
                "Name:",
                "Gender:",
                "Guardian Name:",
                "Village:",
                "Post Office:",
                "Police Station:",
                "District:",
                "Pin:",
                "Country:",
                "State:",
                "Email:",
                "Phone:",
                "Date of Birth:",
                "Board Name:",
                "Institution:",
                "Roll No:",
                "Passing Year:",
                "Subject 1:",
                "Subject 2:",
                "Subject 3:",
                "Subject 4:",
                "Subject 5:",
                "Mark 1:",
                "Mark 2:",
                "Mark 3:",
                "Mark 4:",
                "Mark 5:"
            };
            string[] values = new[]
            {
                course,
                name,
                gender,
                guardianname,
                village,
                postoffice,
                policestation,
                district,
                pin,
                country,
                state,
                email,
                phone,
                dateofbirth,
                boardname,
                institution,
                rollno,
                passingyear,
                subject1,
                subject2,
                subject3,
                subject4,
                subject5,
                mark1,
                mark2,
                mark3,
                mark4,
                mark5
            };
            var form2 = new Form2(labels, values);
            form2.Show();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            name = textBox3.Text;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                gender = "male";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                gender = "female";
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            guardianname = textBox5.Text;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            village = textBox6.Text;
            if (checkBox1.Checked)
            {
                textBox12.Text = village;
            }

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            postoffice = textBox7.Text;
            if (checkBox1.Checked)
            {
                textBox13.Text = postoffice;
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            policestation = textBox8.Text;
            if (checkBox1.Checked)
            {
                textBox14.Text = policestation;
            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            district = textBox9.Text;
            if (checkBox1.Checked)
            {
                textBox15.Text = district;
            }
        }



        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            pin = Convert.ToString(textBox10.Text);
            if (checkBox1.Checked)
            {
                textBox16.Text = pin;
            }
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
            country = textBox11.Text;
            if (checkBox1.Checked)
            {
                textBox17.Text = country;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            state = comboBox2.Text;
            if (checkBox1.Checked)
            {
                comboBox3.Text = state;
            }

        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {
            email = textBox18.Text;
        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {
            phone = Convert.ToString(textBox19.Text);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateofbirth = dateTimePicker1.Text;
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            boardname = comboBox5.Text;
        }

        private void textBox22_TextChanged(object sender, EventArgs e)
        {
            institution = textBox22.Text;
        }

        private void textBox21_TextChanged(object sender, EventArgs e)
        {
            rollno = Convert.ToString(textBox21.Text);
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            passingyear = comboBox4.Text;
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            subject1 = comboBox6.Text;
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            subject2 = comboBox7.Text;
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            subject3 = comboBox8.Text;
        }

        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            subject4 = comboBox9.Text;
        }

        private void comboBox10_SelectedIndexChanged(object sender, EventArgs e)
        {
            subject5 = comboBox10.Text;
        }

        private void textBox23_TextChanged(object sender, EventArgs e)
        {
            mark1 = Convert.ToString(textBox23.Text);
        }

        private void textBox24_TextChanged(object sender, EventArgs e)
        {
            mark2 = Convert.ToString(textBox24.Text);
        }

        private void textBox25_TextChanged(object sender, EventArgs e)
        {
            mark3 = Convert.ToString(textBox25.Text);
        }

        private void textBox26_TextChanged(object sender, EventArgs e)
        {
            mark4 = Convert.ToString(textBox26.Text);
        }

        private void textBox27_TextChanged(object sender, EventArgs e)
        {
            mark5 = Convert.ToString(textBox27.Text);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox12.Text = textBox6.Text;
                textBox12.Enabled = false;
                textBox13.Text = textBox7.Text;
                textBox13.Enabled = false; // Disable textBox13 when checkbox is checked
                textBox14.Text = textBox8.Text;
                textBox14.Enabled = false; // Disable textBox14 when checkbox is checked
                textBox15.Text = textBox9.Text;
                textBox15.Enabled = false; // Disable textBox15 when checkbox is checked
                textBox16.Text = textBox10.Text;
                textBox16.Enabled = false; // Disable textBox16 when checkbox is checked
                textBox17.Text = textBox11.Text;
                textBox17.Enabled = false; // Disable textBox17 when checkbox is checked
                comboBox3.Text = comboBox2.Text;
                comboBox3.Enabled = false; // Disable comboBox3 when checkbox is checked
            }
            else
            {
                textBox12.Enabled = true; // Enable textBox12 when checkbox is unchecked
                textBox13.Enabled = true; // Enable textBox13 when checkbox is unchecked
                textBox14.Enabled = true; // Enable textBox14 when checkbox is unchecked
                textBox15.Enabled = true; // Enable textBox15 when checkbox is unchecked
                textBox16.Enabled = true; // Enable textBox16 when checkbox is unchecked
                textBox17.Enabled = true; // Enable textBox17 when checkbox is unchecked
                comboBox3.Enabled = true; // Enable comboBox3 when checkbox is unchecked
            }
        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {
            //if (checkBox1.Checked)
            //{
            //    textBox13.Text = textBox7.Text;
            //}
        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox17_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                textBox20.Visible = true;
            }
            else
            {
                textBox20.Visible = false;
            }
        }

        // Add this method for pin code input validation
        private void textBox10_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only digits and control keys (e.g., backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Prevent more than 6 digits
            if (char.IsDigit(e.KeyChar) && textBox10.Text.Length >= 6 && textBox10.SelectionLength == 0)
            {
                e.Handled = true;
            }
        }

        // Add this method for permanent pin code input validation
        private void textBox16_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only digits and control keys (e.g., backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Prevent more than 6 digits
            if (char.IsDigit(e.KeyChar) && textBox16.Text.Length >= 6 && textBox16.SelectionLength == 0)
            {
                e.Handled = true;
            }
        }

        // Add this method for email input validation (only validate if not empty)
        private void textBox18_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            var emailText = textBox18.Text;
            if (!string.IsNullOrWhiteSpace(emailText) && !System.Text.RegularExpressions.Regex.IsMatch(emailText, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
            }
        }

        // Update: Only allow digits in roll number, any length (not exactly 6 digits)
        private void textBox21_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Only validate if not empty and must be all digits
            if (!string.IsNullOrWhiteSpace(textBox21.Text) && !textBox21.Text.All(char.IsDigit))
            {
                MessageBox.Show("Roll number must contain only digits (0-9).", "Invalid Roll Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
            }
            // Allow empty value to pass validation (so user can leave the field or close the form)
        }

        // Update: Allow any number of digits in roll number
        private void textBox21_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only digits and control keys (e.g., backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Remove length restriction
        }

        // Add this method for phone number input validation
        private void textBox19_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only digits and control keys (e.g., backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Prevent more than 10 digits
            if (char.IsDigit(e.KeyChar) && textBox19.Text.Length >= 10 && textBox19.SelectionLength == 0)
            {
                e.Handled = true;
            }
        }

        // Add this method for another number input validation
        private void textBox20_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only digits and control keys (e.g., backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Prevent more than 10 digits
            if (char.IsDigit(e.KeyChar) && textBox20.Text.Length >= 10 && textBox20.SelectionLength == 0)
            {
                e.Handled = true;
            }
        }

        // Add this method for mark textbox input validation (only digits, max 3 chars)
        private void markTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Simulate the new value after key press
            string newText = tb.Text;
            if (!char.IsControl(e.KeyChar))
            {
                if (tb.SelectionLength > 0)
                {
                    newText = tb.Text.Remove(tb.SelectionStart, tb.SelectionLength);
                    newText = newText.Insert(tb.SelectionStart, e.KeyChar.ToString());
                }
                else
                {
                    newText = tb.Text.Insert(tb.SelectionStart, e.KeyChar.ToString());
                }
            }
            if (int.TryParse(newText, out int value))
            {
                if (value > 100)
                {
                    e.Handled = true;
                }
            }
            // Prevent more than 3 digits
            if (char.IsDigit(e.KeyChar) && newText.Length > 3)
            {
                e.Handled = true;
            }
        }

        // Add this method for mark textbox range validation (0-100 inclusive)
        private void markTextBox_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (!string.IsNullOrWhiteSpace(tb.Text))
            {
                if (!int.TryParse(tb.Text, out int value) || value < 0 || value > 100)
                {
                    MessageBox.Show("Please enter a valid mark between 0 and 100.", "Invalid Mark", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Cancel = true;
                }
            }
        }

        // Helper to update subject ComboBoxes
        private void UpdateSubjectComboBoxes()
        {
            var selected = new HashSet<string>(new[] {
                comboBox6.Text, comboBox7.Text, comboBox8.Text, comboBox9.Text, comboBox10.Text
            }.Where(s => !string.IsNullOrWhiteSpace(s)));

            ComboBox[] boxes = { comboBox6, comboBox7, comboBox8, comboBox9, comboBox10 };
            foreach (var box in boxes)
            {
                var current = box.Text;
                box.SelectedIndexChanged -= SubjectComboBox_SelectedIndexChanged;
                box.Items.Clear();
                foreach (var subj in allSubjects)
                {
                    if (!selected.Contains(subj) || subj == current)
                        box.Items.Add(subj);
                }
                box.Text = current;
                box.SelectedIndexChanged += SubjectComboBox_SelectedIndexChanged;
            }
        }

        // Unified handler for all subject ComboBoxes
        private void SubjectComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateSubjectComboBoxes();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

namespace Application_Form
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox textBoxDisplay;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxDisplay = new TextBox();
            SuspendLayout();
            // 
            // textBoxDisplay
            // 
            textBoxDisplay.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBoxDisplay.Font = new Font("Segoe UI", 11F);
            textBoxDisplay.Location = new Point(20, 20);
            textBoxDisplay.Multiline = true;
            textBoxDisplay.Name = "textBoxDisplay";
            textBoxDisplay.ReadOnly = true;
            textBoxDisplay.ScrollBars = ScrollBars.Vertical;
            textBoxDisplay.Size = new Size(560, 360);
            textBoxDisplay.TabIndex = 0;
            textBoxDisplay.TextChanged += textBoxDisplay_TextChanged;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(600, 400);
            Controls.Add(textBoxDisplay);
            Name = "Form2";
            Text = "Submitted Data";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
    }
}

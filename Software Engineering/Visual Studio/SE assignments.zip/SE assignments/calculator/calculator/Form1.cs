namespace calculator
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
        }

        string st = "";
        double firstOperand = 0;
        double secondOperand = 0;
        string operation = "";
        bool operationPressed = false;

        private void one_Click(object sender, EventArgs e)
        {
            AppendDigit("1");
        }
        private void two_Click(object sender, EventArgs e)
        {
            AppendDigit("2");
        }
        private void three_Click(object sender, EventArgs e)
        {
            AppendDigit("3");
        }
        private void four_Click(object sender, EventArgs e)
        {
            AppendDigit("4");
        }
        private void five_Click(object sender, EventArgs e)
        {
            AppendDigit("5");
        }
        private void six_Click(object sender, EventArgs e)
        {
            AppendDigit("6");
        }
        private void seven_Click(object sender, EventArgs e)
        {
            AppendDigit("7");
        }
        private void eight_Click(object sender, EventArgs e)
        {
            AppendDigit("8");
        }
        private void nine_Click(object sender, EventArgs e)
        {
            AppendDigit("9");
        }
        private void zero_Click(object sender, EventArgs e)
        {
            AppendDigit("0");
        }

        private void AppendDigit(string digit)
        {
            if (operationPressed || labelResult.Text == "0")
            {
                labelResult.Text = digit;
                operationPressed = false;
            }
            else
            {
                labelResult.Text += digit;
            }
        }

        private void add_Click_1(object sender, EventArgs e)
        {
            SetOperation("+");
        }
        private void sub_Click(object sender, EventArgs e)
        {
            SetOperation("-");
        }
        private void mult_Click(object sender, EventArgs e)
        {
            SetOperation("*");
        }
        private void div_Click(object sender, EventArgs e)
        {
            SetOperation("/");
        }

        private void SetOperation(string op)
        {
            if (double.TryParse(labelResult.Text, out firstOperand))
            {
                operation = op;
                operationPressed = true;
                labelOperation.Text = labelResult.Text + " " + op;
            }
        }

        private void equals_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(labelResult.Text, out secondOperand))
                return;
            double result = 0;
            switch (operation)
            {
                case "+":
                    result = firstOperand + secondOperand;
                    break;
                case "-":
                    result = firstOperand - secondOperand;
                    break;
                case "*":
                    result = firstOperand * secondOperand;
                    break;
                case "/":
                    if (secondOperand == 0)
                    {
                        labelResult.Text = "Error";
                        labelOperation.Text = "";
                        return;
                    }
                    result = firstOperand / secondOperand;
                    break;
                default:
                    return;
            }
            labelResult.Text = result.ToString();
            labelOperation.Text = "";
            operation = "";
            operationPressed = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            labelResult.Text = "0";
            labelOperation.Text = "";
            st = "";
            firstOperand = 0;
            secondOperand = 0;
            operation = "";
            operationPressed = false;
        }
    }
}

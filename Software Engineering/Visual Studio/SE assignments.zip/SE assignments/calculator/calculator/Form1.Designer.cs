﻿namespace calculator
{
    partial class form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            one = new Button();
            two = new Button();
            three = new Button();
            four = new Button();
            five = new Button();
            six = new Button();
            seven = new Button();
            eight = new Button();
            nine = new Button();
            zero = new Button();
            div = new Button();
            mult = new Button();
            sub = new Button();
            add = new Button();
            labelResult = new Label();
            labelOperation = new Label();
            equals = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // one
            // 
            one.BackColor = Color.Black;
            one.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            one.ForeColor = Color.White;
            one.Location = new Point(23, 214);
            one.Name = "one";
            one.Size = new Size(47, 48);
            one.TabIndex = 0;
            one.Text = "1";
            one.TextAlign = ContentAlignment.MiddleRight;
            one.UseVisualStyleBackColor = false;
            one.Click += one_Click;
            // 
            // two
            // 
            two.BackColor = Color.Black;
            two.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            two.ForeColor = Color.White;
            two.Location = new Point(76, 214);
            two.Name = "two";
            two.Size = new Size(47, 48);
            two.TabIndex = 1;
            two.Text = "2";
            two.TextAlign = ContentAlignment.MiddleRight;
            two.UseVisualStyleBackColor = false;
            two.Click += two_Click;
            // 
            // three
            // 
            three.BackColor = Color.Black;
            three.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            three.ForeColor = Color.White;
            three.Location = new Point(129, 214);
            three.Name = "three";
            three.Size = new Size(47, 48);
            three.TabIndex = 2;
            three.Text = "3";
            three.TextAlign = ContentAlignment.MiddleRight;
            three.UseVisualStyleBackColor = false;
            three.Click += three_Click;
            // 
            // four
            // 
            four.BackColor = Color.Black;
            four.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            four.ForeColor = Color.White;
            four.Location = new Point(23, 160);
            four.Name = "four";
            four.Size = new Size(47, 48);
            four.TabIndex = 3;
            four.Text = "4";
            four.TextAlign = ContentAlignment.MiddleRight;
            four.UseVisualStyleBackColor = false;
            four.Click += four_Click;
            // 
            // five
            // 
            five.BackColor = Color.Black;
            five.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            five.ForeColor = Color.White;
            five.Location = new Point(76, 160);
            five.Name = "five";
            five.Size = new Size(47, 48);
            five.TabIndex = 4;
            five.Text = "5";
            five.TextAlign = ContentAlignment.MiddleRight;
            five.UseVisualStyleBackColor = false;
            five.Click += five_Click;
            // 
            // six
            // 
            six.BackColor = Color.Black;
            six.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            six.ForeColor = Color.White;
            six.Location = new Point(129, 160);
            six.Name = "six";
            six.Size = new Size(47, 48);
            six.TabIndex = 5;
            six.Text = "6";
            six.TextAlign = ContentAlignment.MiddleRight;
            six.UseVisualStyleBackColor = false;
            six.Click += six_Click;
            // 
            // seven
            // 
            seven.BackColor = Color.Black;
            seven.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            seven.ForeColor = Color.White;
            seven.Location = new Point(23, 106);
            seven.Name = "seven";
            seven.Size = new Size(47, 48);
            seven.TabIndex = 6;
            seven.Text = "7";
            seven.TextAlign = ContentAlignment.MiddleRight;
            seven.UseVisualStyleBackColor = false;
            seven.Click += seven_Click;
            // 
            // eight
            // 
            eight.BackColor = Color.Black;
            eight.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            eight.ForeColor = Color.White;
            eight.Location = new Point(76, 106);
            eight.Name = "eight";
            eight.Size = new Size(47, 48);
            eight.TabIndex = 7;
            eight.Text = "8";
            eight.TextAlign = ContentAlignment.MiddleRight;
            eight.UseVisualStyleBackColor = false;
            eight.Click += eight_Click;
            // 
            // nine
            // 
            nine.BackColor = Color.Black;
            nine.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nine.ForeColor = Color.White;
            nine.Location = new Point(129, 106);
            nine.Name = "nine";
            nine.Size = new Size(47, 48);
            nine.TabIndex = 8;
            nine.Text = "9";
            nine.TextAlign = ContentAlignment.MiddleRight;
            nine.UseVisualStyleBackColor = false;
            nine.Click += nine_Click;
            // 
            // zero
            // 
            zero.BackColor = Color.Black;
            zero.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            zero.ForeColor = Color.White;
            zero.Location = new Point(76, 268);
            zero.Name = "zero";
            zero.Size = new Size(47, 48);
            zero.TabIndex = 9;
            zero.Text = "0";
            zero.TextAlign = ContentAlignment.MiddleRight;
            zero.UseVisualStyleBackColor = false;
            zero.Click += zero_Click;
            // 
            // div
            // 
            div.BackColor = Color.Black;
            div.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            div.ForeColor = Color.White;
            div.Location = new Point(182, 106);
            div.Name = "div";
            div.Size = new Size(47, 48);
            div.TabIndex = 11;
            div.Text = "/";
            div.TextAlign = ContentAlignment.MiddleRight;
            div.UseVisualStyleBackColor = false;
            div.Click += div_Click;
            // 
            // mult
            // 
            mult.BackColor = Color.Black;
            mult.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            mult.ForeColor = Color.White;
            mult.Location = new Point(182, 160);
            mult.Name = "mult";
            mult.Size = new Size(47, 48);
            mult.TabIndex = 12;
            mult.Text = "x";
            mult.TextAlign = ContentAlignment.MiddleRight;
            mult.UseVisualStyleBackColor = false;
            mult.Click += mult_Click;
            // 
            // sub
            // 
            sub.BackColor = Color.Black;
            sub.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            sub.ForeColor = Color.White;
            sub.Location = new Point(182, 214);
            sub.Name = "sub";
            sub.Size = new Size(47, 48);
            sub.TabIndex = 13;
            sub.Text = "-";
            sub.TextAlign = ContentAlignment.MiddleRight;
            sub.UseVisualStyleBackColor = false;
            sub.Click += sub_Click;
            // 
            // add
            // 
            add.BackColor = Color.Black;
            add.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            add.ForeColor = Color.White;
            add.Location = new Point(182, 268);
            add.Name = "add";
            add.Size = new Size(47, 48);
            add.TabIndex = 14;
            add.Text = "+";
            add.TextAlign = ContentAlignment.MiddleRight;
            add.UseVisualStyleBackColor = false;
            add.Click += add_Click_1;
            // 
            // labelResult
            // 
            labelResult.BackColor = Color.White;
            labelResult.BorderStyle = BorderStyle.Fixed3D;
            labelResult.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelResult.Location = new Point(23, 65);
            labelResult.Name = "labelResult";
            labelResult.Size = new Size(206, 35);
            labelResult.TabIndex = 15;
            labelResult.Text = "0";
            labelResult.TextAlign = ContentAlignment.MiddleRight;
            // 
            // labelOperation
            // 
            labelOperation.BackColor = Color.White;
            labelOperation.BorderStyle = BorderStyle.Fixed3D;
            labelOperation.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelOperation.Location = new Point(23, 24);
            labelOperation.Name = "labelOperation";
            labelOperation.Size = new Size(206, 35);
            labelOperation.TabIndex = 16;
            labelOperation.TextAlign = ContentAlignment.MiddleRight;
            // 
            // equals
            // 
            equals.BackColor = Color.Black;
            equals.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            equals.ForeColor = Color.White;
            equals.Location = new Point(129, 268);
            equals.Name = "equals";
            equals.Size = new Size(47, 48);
            equals.TabIndex = 17;
            equals.Text = "=";
            equals.TextAlign = ContentAlignment.MiddleRight;
            equals.UseVisualStyleBackColor = false;
            equals.Click += equals_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.Font = new Font("Sans Serif Collection", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(23, 268);
            button1.Name = "button1";
            button1.Size = new Size(47, 48);
            button1.TabIndex = 18;
            button1.Text = "C";
            button1.TextAlign = ContentAlignment.TopRight;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(252, 336);
            Controls.Add(button1);
            Controls.Add(equals);
            Controls.Add(labelOperation);
            Controls.Add(labelResult);
            Controls.Add(add);
            Controls.Add(sub);
            Controls.Add(mult);
            Controls.Add(div);
            Controls.Add(zero);
            Controls.Add(nine);
            Controls.Add(eight);
            Controls.Add(seven);
            Controls.Add(six);
            Controls.Add(five);
            Controls.Add(four);
            Controls.Add(three);
            Controls.Add(two);
            Controls.Add(one);
            MaximizeBox = false;
            MinimizeBox = true;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Calculator";
            ResumeLayout(false);
        }

        #endregion

        private Button one;
        private Button two;
        private Button three;
        private Button four;
        private Button five;
        private Button six;
        private Button seven;
        private Button eight;
        private Button nine;
        private Button zero;
        private Button div;
        private Button mult;
        private Button sub;
        private Button add;
        private Label labelResult;
        private Label labelOperation;
        private Button equals;
        private Button button1;
    }
}

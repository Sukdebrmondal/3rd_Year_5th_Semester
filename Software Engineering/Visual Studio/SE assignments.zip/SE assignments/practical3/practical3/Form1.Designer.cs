﻿namespace practical3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            comboBox1 = new ComboBox();
            checkBox1 = new CheckBox();
            textBox9 = new TextBox();
            comboBox2 = new ComboBox();
            comboBox3 = new ComboBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            textBox15 = new TextBox();
            textBox16 = new TextBox();
            textBox17 = new TextBox();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            checkBox2 = new CheckBox();
            dateTimePicker1 = new DateTimePicker();
            label24 = new Label();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            label25 = new Label();
            label26 = new Label();
            label27 = new Label();
            label28 = new Label();
            label29 = new Label();
            label30 = new Label();
            comboBox4 = new ComboBox();
            comboBox5 = new ComboBox();
            comboBox6 = new ComboBox();
            comboBox7 = new ComboBox();
            comboBox8 = new ComboBox();
            button1 = new Button();
            label36 = new Label();
            comboBox9 = new ComboBox();
            textBox18 = new TextBox();
            textBox19 = new TextBox();
            comboBox10 = new ComboBox();
            textBox20 = new TextBox();
            textBox21 = new TextBox();
            textBox22 = new TextBox();
            textBox23 = new TextBox();
            textBox24 = new TextBox();
            label31 = new Label();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 72);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 0;
            label1.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(23, 105);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 1;
            label2.Text = "Gender";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(23, 138);
            label3.Name = "label3";
            label3.Size = new Size(87, 15);
            label3.TabIndex = 2;
            label3.Text = "guardian name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(23, 167);
            label4.Name = "label4";
            label4.Size = new Size(70, 21);
            label4.TabIndex = 3;
            label4.Text = "Address";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(22, 464);
            label5.Name = "label5";
            label5.Size = new Size(36, 15);
            label5.TabIndex = 4;
            label5.Text = "email";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(23, 499);
            label6.Name = "label6";
            label6.Size = new Size(41, 15);
            label6.TabIndex = 5;
            label6.Text = "phone";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(23, 534);
            label7.Name = "label7";
            label7.Size = new Size(53, 15);
            label7.TabIndex = 6;
            label7.Text = "category";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(24, 571);
            label8.Name = "label8";
            label8.Size = new Size(75, 15);
            label8.TabIndex = 7;
            label8.Text = "Date Of Birth";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(88, 69);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(129, 23);
            textBox1.TabIndex = 8;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(117, 135);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(229, 23);
            textBox2.TabIndex = 11;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(40, 193);
            label9.Name = "label9";
            label9.Size = new Size(42, 15);
            label9.TabIndex = 12;
            label9.Text = "Village";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(40, 228);
            label10.Name = "label10";
            label10.Size = new Size(20, 15);
            label10.TabIndex = 13;
            label10.Text = "PS";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(40, 260);
            label11.Name = "label11";
            label11.Size = new Size(65, 15);
            label11.TabIndex = 14;
            label11.Text = "Post Office";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(40, 289);
            label12.Name = "label12";
            label12.Size = new Size(44, 15);
            label12.TabIndex = 15;
            label12.Text = "District";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(40, 322);
            label13.Name = "label13";
            label13.Size = new Size(24, 15);
            label13.TabIndex = 16;
            label13.Text = "Pin";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(40, 354);
            label14.Name = "label14";
            label14.Size = new Size(50, 15);
            label14.TabIndex = 17;
            label14.Text = "Country";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(40, 391);
            label15.Name = "label15";
            label15.Size = new Size(33, 15);
            label15.TabIndex = 18;
            label15.Text = "State";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(101, 190);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(129, 23);
            textBox3.TabIndex = 19;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(101, 225);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(129, 23);
            textBox4.TabIndex = 20;
            textBox4.TextChanged += textBox4_TextChanged;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(111, 257);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(129, 23);
            textBox5.TabIndex = 21;
            textBox5.TextChanged += textBox5_TextChanged;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(101, 286);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(129, 23);
            textBox6.TabIndex = 22;
            textBox6.TextChanged += textBox6_TextChanged;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(88, 319);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(129, 23);
            textBox7.TabIndex = 23;
            textBox7.TextChanged += textBox7_TextChanged;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(96, 354);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(129, 23);
            textBox8.TabIndex = 24;
            textBox8.TextChanged += textBox8_TextChanged;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(64, 464);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(240, 23);
            textBox10.TabIndex = 26;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(70, 496);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(129, 23);
            textBox11.TabIndex = 27;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Andhra Pradesh", "Arunachal Pradesh", "West Bengal", "Assam", "Bihar", "Kerala" });
            comboBox1.Location = new Point(79, 388);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 23);
            comboBox1.TabIndex = 28;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(221, 499);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(142, 19);
            checkBox1.TabIndex = 29;
            checkBox1.Text = "Have another number";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(369, 496);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(129, 23);
            textBox9.TabIndex = 30;
            textBox9.Visible = false;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "GEN", "OBC-A", "OBC-B", "ST", "SC", "GEN-BPL/EWS" });
            comboBox2.Location = new Point(82, 534);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(151, 23);
            comboBox2.TabIndex = 31;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "Andhra Pradesh", "Arunachal Pradesh", "West Bengal", "Assam", "Bihar", "Kerala" });
            comboBox3.Location = new Point(425, 391);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(151, 23);
            comboBox3.TabIndex = 46;
            comboBox3.SelectedIndexChanged += comboBox3_SelectedIndexChanged;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(442, 357);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(129, 23);
            textBox12.TabIndex = 45;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(434, 322);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(129, 23);
            textBox13.TabIndex = 44;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(447, 289);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(129, 23);
            textBox14.TabIndex = 43;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(457, 260);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(129, 23);
            textBox15.TabIndex = 42;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(447, 228);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(129, 23);
            textBox16.TabIndex = 41;
            // 
            // textBox17
            // 
            textBox17.Location = new Point(447, 193);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(129, 23);
            textBox17.TabIndex = 40;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(386, 394);
            label16.Name = "label16";
            label16.Size = new Size(33, 15);
            label16.TabIndex = 39;
            label16.Text = "State";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(386, 357);
            label17.Name = "label17";
            label17.Size = new Size(50, 15);
            label17.TabIndex = 38;
            label17.Text = "Country";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(386, 325);
            label18.Name = "label18";
            label18.Size = new Size(24, 15);
            label18.TabIndex = 37;
            label18.Text = "Pin";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(386, 292);
            label19.Name = "label19";
            label19.Size = new Size(44, 15);
            label19.TabIndex = 36;
            label19.Text = "District";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(386, 263);
            label20.Name = "label20";
            label20.Size = new Size(65, 15);
            label20.TabIndex = 35;
            label20.Text = "Post Office";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(386, 231);
            label21.Name = "label21";
            label21.Size = new Size(20, 15);
            label21.TabIndex = 34;
            label21.Text = "PS";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(386, 196);
            label22.Name = "label22";
            label22.Size = new Size(42, 15);
            label22.TabIndex = 33;
            label22.Text = "Village";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label23.Location = new Point(369, 170);
            label23.Name = "label23";
            label23.Size = new Size(158, 21);
            label23.TabIndex = 32;
            label23.Text = "Parmanent Address";
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(533, 174);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(111, 19);
            checkBox2.TabIndex = 47;
            checkBox2.Text = "same as address";
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(105, 565);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(228, 23);
            dateTimePicker1.TabIndex = 48;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label24.Location = new Point(21, 28);
            label24.Name = "label24";
            label24.Size = new Size(152, 25);
            label24.TabIndex = 49;
            label24.Text = "Admission Class";
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(89, 13);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(63, 19);
            radioButton2.TabIndex = 10;
            radioButton2.TabStop = true;
            radioButton2.Text = "Female";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(10, 13);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(51, 19);
            radioButton1.TabIndex = 9;
            radioButton1.TabStop = true;
            radioButton1.Text = "Male";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(63, 12);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(51, 19);
            radioButton3.TabIndex = 51;
            radioButton3.TabStop = true;
            radioButton3.Text = "M.Sc";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Location = new Point(10, 12);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(47, 19);
            radioButton4.TabIndex = 50;
            radioButton4.TabStop = true;
            radioButton4.Text = "M.A";
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += radioButton4_CheckedChanged;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label25.Location = new Point(27, 613);
            label25.Name = "label25";
            label25.Size = new Size(146, 25);
            label25.TabIndex = 52;
            label25.Text = "Details of 10+2";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(27, 650);
            label26.Name = "label26";
            label26.Size = new Size(87, 15);
            label26.TabIndex = 53;
            label26.Text = "Name of Board";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(27, 681);
            label27.Name = "label27";
            label27.Size = new Size(110, 15);
            label27.TabIndex = 54;
            label27.Text = "Name of Institution";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(27, 710);
            label28.Name = "label28";
            label28.Size = new Size(44, 15);
            label28.TabIndex = 55;
            label28.Text = "Roll no";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(27, 737);
            label29.Name = "label29";
            label29.Size = new Size(86, 15);
            label29.TabIndex = 56;
            label29.Text = "Year of passing";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label30.Location = new Point(397, 613);
            label30.Name = "label30";
            label30.Size = new Size(86, 25);
            label30.TabIndex = 57;
            label30.Text = "Subjects";
            // 
            // comboBox4
            // 
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "1st language", "2nd language", "Urdu", "Hindi" });
            comboBox4.Location = new Point(386, 647);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(213, 23);
            comboBox4.TabIndex = 58;
            comboBox4.Text = "Subject";
            comboBox4.SelectedIndexChanged += comboBox4_SelectedIndexChanged;
            // 
            // comboBox5
            // 
            comboBox5.FormattingEnabled = true;
            comboBox5.Items.AddRange(new object[] { "1st language", "2nd language", "Urdu", "Hindi" });
            comboBox5.Location = new Point(386, 676);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(213, 23);
            comboBox5.TabIndex = 59;
            comboBox5.Text = "Subject";
            comboBox5.SelectedIndexChanged += comboBox5_SelectedIndexChanged;
            // 
            // comboBox6
            // 
            comboBox6.FormattingEnabled = true;
            comboBox6.Items.AddRange(new object[] { "Physics", "Chemistry", "Math", "Biology", "Computer Application", "Computer Science", "Nutrition" });
            comboBox6.Location = new Point(386, 705);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new Size(213, 23);
            comboBox6.TabIndex = 62;
            comboBox6.Text = "Subject";
            comboBox6.SelectedIndexChanged += comboBox6_SelectedIndexChanged;
            // 
            // comboBox7
            // 
            comboBox7.FormattingEnabled = true;
            comboBox7.Items.AddRange(new object[] { "Physics", "Chemistry", "Math", "Biology", "Computer Application", "Computer Science", "Nutrition" });
            comboBox7.Location = new Point(386, 734);
            comboBox7.Name = "comboBox7";
            comboBox7.Size = new Size(213, 23);
            comboBox7.TabIndex = 64;
            comboBox7.Text = "Subject";
            comboBox7.SelectedIndexChanged += comboBox7_SelectedIndexChanged;
            // 
            // comboBox8
            // 
            comboBox8.FormattingEnabled = true;
            comboBox8.Items.AddRange(new object[] { "Physics", "Chemistry", "Math", "Biology", "Computer Application", "Computer Science", "Nutrition" });
            comboBox8.Location = new Point(386, 763);
            comboBox8.Name = "comboBox8";
            comboBox8.Size = new Size(213, 23);
            comboBox8.TabIndex = 66;
            comboBox8.Text = "Subject";
            comboBox8.SelectedIndexChanged += comboBox8_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.Location = new Point(221, 795);
            button1.Name = "button1";
            button1.Size = new Size(135, 31);
            button1.TabIndex = 68;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label36.Location = new Point(27, 431);
            label36.Name = "label36";
            label36.Size = new Size(131, 21);
            label36.TabIndex = 69;
            label36.Text = "Personal details";
            // 
            // comboBox9
            // 
            comboBox9.FormattingEnabled = true;
            comboBox9.Items.AddRange(new object[] { "2019", "2020" });
            comboBox9.Location = new Point(119, 734);
            comboBox9.Name = "comboBox9";
            comboBox9.Size = new Size(98, 23);
            comboBox9.TabIndex = 70;
            // 
            // textBox18
            // 
            textBox18.Location = new Point(79, 707);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(129, 23);
            textBox18.TabIndex = 71;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(143, 678);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(237, 23);
            textBox19.TabIndex = 72;
            // 
            // comboBox10
            // 
            comboBox10.FormattingEnabled = true;
            comboBox10.Items.AddRange(new object[] { "WBCHSE", "CBSE", "ICS", "Other" });
            comboBox10.Location = new Point(120, 647);
            comboBox10.Name = "comboBox10";
            comboBox10.Size = new Size(98, 23);
            comboBox10.TabIndex = 73;
            // 
            // textBox20
            // 
            textBox20.Enabled = false;
            textBox20.Location = new Point(605, 647);
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(67, 23);
            textBox20.TabIndex = 74;
            // 
            // textBox21
            // 
            textBox21.Enabled = false;
            textBox21.Location = new Point(605, 676);
            textBox21.Name = "textBox21";
            textBox21.Size = new Size(67, 23);
            textBox21.TabIndex = 75;
            // 
            // textBox22
            // 
            textBox22.Enabled = false;
            textBox22.Location = new Point(605, 707);
            textBox22.Name = "textBox22";
            textBox22.Size = new Size(67, 23);
            textBox22.TabIndex = 76;
            // 
            // textBox23
            // 
            textBox23.Enabled = false;
            textBox23.Location = new Point(605, 734);
            textBox23.Name = "textBox23";
            textBox23.Size = new Size(67, 23);
            textBox23.TabIndex = 77;
            // 
            // textBox24
            // 
            textBox24.Enabled = false;
            textBox24.Location = new Point(605, 763);
            textBox24.Name = "textBox24";
            textBox24.Size = new Size(67, 23);
            textBox24.TabIndex = 78;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(617, 621);
            label31.Name = "label31";
            label31.Size = new Size(39, 15);
            label31.TabIndex = 79;
            label31.Text = "Marks";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radioButton3);
            groupBox1.Controls.Add(radioButton4);
            groupBox1.Location = new Point(179, 16);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(124, 37);
            groupBox1.TabIndex = 80;
            groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(radioButton2);
            groupBox2.Controls.Add(radioButton1);
            groupBox2.Location = new Point(107, 92);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(158, 38);
            groupBox2.TabIndex = 81;
            groupBox2.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(684, 841);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label31);
            Controls.Add(textBox24);
            Controls.Add(textBox23);
            Controls.Add(textBox22);
            Controls.Add(textBox21);
            Controls.Add(textBox20);
            Controls.Add(comboBox10);
            Controls.Add(textBox19);
            Controls.Add(textBox18);
            Controls.Add(comboBox9);
            Controls.Add(label36);
            Controls.Add(button1);
            Controls.Add(comboBox8);
            Controls.Add(comboBox7);
            Controls.Add(comboBox6);
            Controls.Add(comboBox5);
            Controls.Add(comboBox4);
            Controls.Add(label30);
            Controls.Add(label29);
            Controls.Add(label28);
            Controls.Add(label27);
            Controls.Add(label26);
            Controls.Add(label25);
            Controls.Add(label24);
            Controls.Add(dateTimePicker1);
            Controls.Add(checkBox2);
            Controls.Add(comboBox3);
            Controls.Add(textBox12);
            Controls.Add(textBox13);
            Controls.Add(textBox14);
            Controls.Add(textBox15);
            Controls.Add(textBox16);
            Controls.Add(textBox17);
            Controls.Add(label16);
            Controls.Add(label17);
            Controls.Add(label18);
            Controls.Add(label19);
            Controls.Add(label20);
            Controls.Add(label21);
            Controls.Add(label22);
            Controls.Add(label23);
            Controls.Add(comboBox2);
            Controls.Add(textBox9);
            Controls.Add(checkBox1);
            Controls.Add(comboBox1);
            Controls.Add(textBox11);
            Controls.Add(textBox10);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox10;
        private TextBox textBox11;
        private ComboBox comboBox1;
        private CheckBox checkBox1;
        private TextBox textBox9;
        private ComboBox comboBox2;
        private ComboBox comboBox3;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private CheckBox checkBox2;
        private DateTimePicker dateTimePicker1;
        private Label label24;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private Label label25;
        private Label label26;
        private Label label27;
        private Label label28;
        private Label label29;
        private Label label30;
        private ComboBox comboBox4;
        private ComboBox comboBox5;
        private ComboBox comboBox6;
        private ComboBox comboBox7;
        private ComboBox comboBox8;
        private Button button1;
        private Label label36;
        private ComboBox comboBox9;
        private TextBox textBox18;
        private TextBox textBox19;
        private ComboBox comboBox10;
        private TextBox textBox20;
        private TextBox textBox21;
        private TextBox textBox22;
        private TextBox textBox23;
        private TextBox textBox24;
        private Label label31;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
    }
}

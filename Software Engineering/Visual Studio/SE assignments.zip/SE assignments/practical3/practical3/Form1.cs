namespace practical3
{
    public partial class Form1 : Form
    {
        public static string course = "";
        public static string name = "";
        public static string gender = "";
        public static string guardian_name = "";
        public static string village = "";
        public static string ps = "";
        public static string po = "";
        public static string dist = "";
        public static string pin = "";
        public static string country = "";
        public static string state = "";
        public static string email = "";
        public static string phone = "";
        public static string ano_phone = "";
        public static string category = "";
        public static string DOB = "";
        public static string NOB = "";
        public static string NOI = "";
        public static string roll = "";
        public static string YOP = "";
        public static string submit = "";
        public static int sub1 = 0;
        public static int sub2 = 0;
        public static int sub3 = 0;
        public static int sub4 = 0;
        public static int sub5 = 0;

        private List<string> subjectList = new List<string> { "1st language", "2nd language", "Urdu", "Hindi", "Physics", "Chemistry", "Math", "Biology", "Computer Application", "Computer Science", "Nutrition" };
        private ComboBox[] subjectComboBoxes;



        public Form1()
        {
            InitializeComponent();
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox4.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox5.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox6.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox7.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox8.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox9.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox10.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            textBox7.KeyPress += textBox7_KeyPress;
            textBox13.KeyPress += textBox13_KeyPress;
            textBox10.Validating += textBox10_Validating;
            textBox11.KeyPress += textBox11_KeyPress;
            textBox9.KeyPress += textBox9_KeyPress;
            textBox18.KeyPress += textBox18_KeyPress;
            textBox20.KeyPress += marks_KeyPress;
            textBox21.KeyPress += marks_KeyPress;
            textBox22.KeyPress += marks_KeyPress;
            textBox23.KeyPress += marks_KeyPress;
            textBox24.KeyPress += marks_KeyPress;

            subjectComboBoxes = new ComboBox[] { comboBox4, comboBox5, comboBox6, comboBox7, comboBox8 };
            foreach (var cb in subjectComboBoxes)
            {
                cb.SelectedIndexChanged += SubjectComboBox_SelectedIndexChanged;
            }
            UpdateSubjectComboBoxes();
        }

        private void SubjectComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateSubjectComboBoxes();
        }

        private void UpdateSubjectComboBoxes()
        {
            var selectedSubjects = subjectComboBoxes.Select(cb => cb.SelectedItem as string).Where(s => !string.IsNullOrEmpty(s) && s != "Subject").ToList();
            foreach (var cb in subjectComboBoxes)
            {
                var current = cb.SelectedItem as string;
                cb.SelectedIndexChanged -= SubjectComboBox_SelectedIndexChanged;
                cb.Items.Clear();
                cb.Items.AddRange(subjectList.Except(selectedSubjects.Where(s => s != current)).ToArray());
                if (!string.IsNullOrEmpty(current) && current != "Subject" && !cb.Items.Contains(current))
                {
                    cb.Items.Add(current);
                }
                if (!string.IsNullOrEmpty(current) && cb.Items.Contains(current))
                {
                    cb.SelectedItem = current;
                }
                else
                {
                    cb.SelectedIndex = -1;
                }
                cb.SelectedIndexChanged += SubjectComboBox_SelectedIndexChanged;
            }
        }

        private void textBox10_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            var email = textBox10.Text;
            if (!string.IsNullOrWhiteSpace(email) && !System.Text.RegularExpressions.Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            course = radioButton4.Text;
        }
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            course = radioButton3.Text;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = radioButton1.Text;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender = radioButton2.Text;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                village = textBox3.Text;
                ps = textBox4.Text;
                po = textBox5.Text;
                dist = textBox6.Text;
                pin = textBox7.Text;
                country = textBox8.Text;
                state = comboBox1.Text;

                textBox17.Text = village;
                textBox16.Text = ps;
                textBox15.Text = po;
                textBox14.Text = dist;
                textBox13.Text = pin;
                textBox12.Text = country;
                comboBox3.Text = state;

                textBox17.Enabled = false;
                textBox16.Enabled = false;
                textBox15.Enabled = false;
                textBox14.Enabled = false;
                textBox13.Enabled = false;
                textBox12.Enabled = false;
                comboBox3.Enabled = false;
            }
            else
            {
                textBox17.Enabled = true;
                textBox16.Enabled = true;
                textBox15.Enabled = true;
                textBox14.Enabled = true;
                textBox13.Enabled = true;
                textBox12.Enabled = true;
                comboBox3.Enabled = true;
            }
        }


        private bool ValidateForm()
        {
            // Check text fields
            if (string.IsNullOrWhiteSpace(textBox1.Text)) { MessageBox.Show("Please enter Name."); textBox1.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox2.Text)) { MessageBox.Show("Please enter Guardian Name."); textBox2.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox3.Text)) { MessageBox.Show("Please enter Village."); textBox3.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox4.Text)) { MessageBox.Show("Please enter PS."); textBox4.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox5.Text)) { MessageBox.Show("Please enter PO."); textBox5.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox6.Text)) { MessageBox.Show("Please enter District."); textBox6.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox7.Text) || textBox7.Text.Length != 6) { MessageBox.Show("Please enter a valid 6-digit Pin."); textBox7.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox8.Text)) { MessageBox.Show("Please enter Country."); textBox8.Focus(); return false; }
            if (comboBox1.SelectedIndex == -1) { MessageBox.Show("Please select State."); comboBox1.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox10.Text)) { MessageBox.Show("Please enter Email."); textBox10.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox11.Text) || textBox11.Text.Length != 10) { MessageBox.Show("Please enter a valid 10-digit Phone Number."); textBox11.Focus(); return false; }
            if (comboBox2.SelectedIndex == -1) { MessageBox.Show("Please select Category."); comboBox2.Focus(); return false; }
            if (comboBox10.SelectedIndex == -1) { MessageBox.Show("Please select Name of Board."); comboBox10.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox19.Text)) { MessageBox.Show("Please enter Name of Institution."); textBox19.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox18.Text) || textBox18.Text.Length != 6) { MessageBox.Show("Please enter a valid 6-digit Roll Number."); textBox18.Focus(); return false; }
            if (comboBox9.SelectedIndex == -1) { MessageBox.Show("Please select Year of Passing."); comboBox9.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox20.Text)) { MessageBox.Show("Please enter Marks for Subject 1."); textBox20.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox21.Text)) { MessageBox.Show("Please enter Marks for Subject 2."); textBox21.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox22.Text)) { MessageBox.Show("Please enter Marks for Subject 3."); textBox22.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox23.Text)) { MessageBox.Show("Please enter Marks for Subject 4."); textBox23.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(textBox24.Text)) { MessageBox.Show("Please enter Marks for Subject 5."); textBox24.Focus(); return false; }
            if (comboBox4.SelectedIndex == -1) { MessageBox.Show("Please select Subject 1."); comboBox4.Focus(); return false; }
            if (comboBox5.SelectedIndex == -1) { MessageBox.Show("Please select Subject 2."); comboBox5.Focus(); return false; }
            if (comboBox6.SelectedIndex == -1) { MessageBox.Show("Please select Subject 3."); comboBox6.Focus(); return false; }
            if (comboBox7.SelectedIndex == -1) { MessageBox.Show("Please select Subject 4."); comboBox7.Focus(); return false; }
            if (comboBox8.SelectedIndex == -1) { MessageBox.Show("Please select Subject 5."); comboBox8.Focus(); return false; }
            if (checkBox1.Checked && (string.IsNullOrWhiteSpace(textBox9.Text) || textBox9.Text.Length != 10)) { MessageBox.Show("Please enter a valid 10-digit Alternate Phone Number."); textBox9.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(gender)) { MessageBox.Show("Please select Gender."); return false; }
            if (string.IsNullOrWhiteSpace(course)) { MessageBox.Show("Please select Course."); return false; }
            return true;
        }

        //submit button
        private void button1_Click(object sender, EventArgs e)
        {
            if (!ValidateForm()) return;

            name = textBox1.Text;
            village = textBox3.Text;
            ps = textBox4.Text;
            po = textBox5.Text;
            dist = textBox6.Text;
            pin = textBox7.Text;
            country = textBox8.Text;
            state = comboBox1.Text;
            email = textBox10.Text;
            phone = textBox11.Text;
            guardian_name = textBox12.Text;
            if (checkBox1.Checked)
            {
                ano_phone = textBox9.Text;
            }
            category = comboBox2.Text;
            DOB = dateTimePicker1.Text;
            NOB = comboBox10.Text;
            NOI = textBox19.Text;
            roll = textBox18.Text;
            YOP = comboBox9.Text;
            sub1 = Convert.ToInt16(textBox20.Text);
            sub2 = Convert.ToInt16(textBox21.Text);
            sub3 = Convert.ToInt16(textBox22.Text);
            sub4 = Convert.ToInt16(textBox23.Text);
            sub5 = Convert.ToInt16(textBox24.Text);



            submit = "course details : "+course + "\n" + "name : "+name + "\n"+"Gender : " + gender + "\n"+ "guardian_name : " + guardian_name + "\n" +
                "village : "+village + "\n" +"Police Station : " + ps + "\n" +"Post Office : "+ po + "\n"+"district : " + dist + "\n"+"Pin : " + pin +
                "\n"+"Country : " + country + "\n" +
                "State : "+state + "\n" +"Email : "+ email + "\n" +"Phone : "+ phone + "\n"+"Another Number : " + ano_phone + "\n" +"Category : "+ category + "\n" +
                "Date of Birth : "+ DOB + "\n" +
                "Name of Board : " + NOB + "\n" +
                "Name of Institute : "+NOI + "\n" +
                "Roll : " + roll + "\n"+
                "Year of passing : "+ YOP+
                "\n"+ comboBox4.Text +" " + sub1 +
                "\n"+ comboBox5.Text + " " + sub2 +
                "\n"+ comboBox6.Text + " " + sub3 +
                "\n" + comboBox7.Text + " " + sub4 +
                "\n" + comboBox8.Text + " " + sub5;

            // Show details in Form2
            Form2 detailsForm = new Form2(submit);
            detailsForm.Show();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                textBox17.Text = textBox3.Text;
            }
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                textBox16.Text = textBox4.Text;
            }
        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                textBox15.Text = textBox5.Text;
            }
        }
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                textBox14.Text = textBox6.Text;
            }
        }
        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                textBox13.Text = textBox7.Text;
            }
        }
        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                textBox12.Text = textBox8.Text;
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                comboBox3.Text = comboBox1.Text;
            }
        }
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox9.Visible = true;
            }
            else
            {
                textBox9.Visible = false;
                textBox9.Text = "";
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox20.Enabled = true;
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox21.Enabled = true;
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox22.Enabled = true;
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox23.Enabled = true;
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox24.Enabled = true;
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only digits and control keys (like backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Prevent input if already 6 digits
            if (char.IsDigit(e.KeyChar) && textBox7.Text.Length >= 6 && !textBox7.SelectedText.Any())
            {
                e.Handled = true;
            }
        }

        private void textBox13_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only digits and control keys (like backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Prevent input if already 6 digits
            if (char.IsDigit(e.KeyChar) && textBox13.Text.Length >= 6 && !textBox13.SelectedText.Any())
            {
                e.Handled = true;
            }
        }

        private void textBox11_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only digits and control keys (like backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Prevent input if already 10 digits
            if (char.IsDigit(e.KeyChar) && textBox11.Text.Length >= 10 && !textBox11.SelectedText.Any())
            {
                e.Handled = true;
            }
        }

        private void textBox9_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only digits and control keys (like backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Prevent input if already 10 digits
            if (char.IsDigit(e.KeyChar) && textBox9.Text.Length >= 10 && !textBox9.SelectedText.Any())
            {
                e.Handled = true;
            }
        }

        private void textBox18_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only digits and control keys (like backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            // Prevent input if already 6 digits
            if (char.IsDigit(e.KeyChar) && textBox18.Text.Length >= 6 && !textBox18.SelectedText.Any())
            {
                e.Handled = true;
            }
        }

        private void marks_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox tb = sender as TextBox;
            // Allow only digits and control keys
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                return;
            }
            // Allow input, but check range after text changes
            // Predict the resulting text after this key press
            string newText = tb.Text;
            if (!char.IsControl(e.KeyChar))
            {
                if (tb.SelectionLength > 0)
                    newText = tb.Text.Remove(tb.SelectionStart, tb.SelectionLength);
                newText = newText.Insert(tb.SelectionStart, e.KeyChar.ToString());
            }
            if (int.TryParse(newText, out int value))
            {
                if (value < 0 || value > 100)
                {
                    e.Handled = true;
                }
            }
            else if (!string.IsNullOrEmpty(newText))
            {
                e.Handled = true;
            }
        }
    }
}
